const md_title = "New title";
const md_navbar = [];
const md_pageRoutes = [
  {
    slug: "home",
    title: "首頁",
    pageContent: `
    <div
        class="absolute inset-0 justify-center text-center min-h-screen flex flex-col"
    >
        <span class="text-4xl text-bold">Hi!</span>
    </div>
    <div class="min-h-screen"></div>
    <div id="displayData" class="break-words"></div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    <div>Hi</div>
    `,
  },
  {
    slug: "secondPage",
    title: "第2頁",
    pageContent: `
    <div
        class="absolute inset-0 justify-center text-center min-h-screen flex flex-col"
    >
        <span class="text-4xl text-bold">This is the second page!</span>
    </div>
    <div class="min-h-screen"></div>
    `,
  },
];

const md_footer = {};