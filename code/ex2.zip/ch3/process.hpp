int salaryCalc(int howMuchAreYouPaid, int howMuchHoursAtYourJob) {
    int calc = howMuchAreYouPaid * howMuchHoursAtYourJob;
    return calc;
}
