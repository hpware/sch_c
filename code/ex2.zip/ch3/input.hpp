#include <iostream>
using namespace std;
int pay() {
    cout << "請輸入終點費: ";
    int workingPayFromUser;
    cin >> workingPayFromUser;

    return workingPayFromUser;
}

int hoursWithPay() {
    cout << "YOUR PAY: ";
    int withYourHours;
    cin >> withYourHours;

    return withYourHours;
}
