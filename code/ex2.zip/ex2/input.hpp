#include <iostream>
using namespace std;
int getH() {
    cout << "請輸入高度: ";
    int workingPayFromUser;
    cin >> workingPayFromUser;

    return workingPayFromUser;
}

int getW() {
    cout << "請輸入重量: ";
    int withYourHours;
    cin >> withYourHours;

    return withYourHours;
}
