float evaBMI (float w, float h) {
	return w/h/h;
}
