#include <iostream>
using namespace std;

int main(int argc, char ** argv) {
    printf("%d", 1234);
    return 0;
}
