#include <iostream>
using namespace std;
float numI;

int main(int argc, char ** argv) {
    cout << "請輸入圓半徑的值 => ";
    cin >> numI;
    cout << "圓半徑的值是: " << numI << endl;
    return 0;
}
