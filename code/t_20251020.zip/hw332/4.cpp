#include <iostream>
using namespace std;
int numI, numV;

int main(int argc, char ** argv) {
    cout << "請輸入空白分隔度升高與體重值 => ";
    cin >> numI >> numV;
    cout << "身高: " << numI << "公分" << endl;
    cout << "體重: " << numI << "公斤" << endl;
    return 0;
}
