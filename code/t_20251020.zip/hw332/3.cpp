#include <iostream>
using namespace std;
double numI;

int main(int argc, char ** argv) {
    cout << "請輸入圓周率的值 => ";
    cin >> numI;
    cout << "圓周率的值是: " << numI << endl;
    return 0;
}
