#include <iostream>
using namespace std;
void output(float calcResult) {
    cout << "BMI = " << calcResult << endl;
}
