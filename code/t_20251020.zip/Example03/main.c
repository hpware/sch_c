#include <stdio.h>

int main() {
    printf("整數= %d\n", 100);
    printf("浮點數= %f\n", 123.5);
}
// idfk
