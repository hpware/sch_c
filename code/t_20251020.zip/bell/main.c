#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Hello\tWorld \a\n");
    return 0;
}
