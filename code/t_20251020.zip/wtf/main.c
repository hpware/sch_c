#include <stdio.h>

int main() {
    printf("我的學號是 51331102 \n");
    printf("C 語言的世界, 您好啊！! \n");
    return 0;
}
