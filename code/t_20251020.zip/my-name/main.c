#include <stdio.h>

int main() {
    printf("我的學號是 51331102 \n");
    return 0;
}
