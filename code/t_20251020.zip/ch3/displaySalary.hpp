#include <iostream>
using namespace std;
void displaySalary(int calcResult) {
    cout << "工資 = " << calcResult << endl;
}
