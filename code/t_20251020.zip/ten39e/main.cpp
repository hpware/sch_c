#include <iostream>
using namespace std;

int main(int argc, char ** argv) {
    printf("十進制 1234 = 十六進制 %10x\n", 1234);
    printf("line 2 \n");
    cout << "十進制 1234 = 十六進制" << endl;
    cout << "line 2\n";
    return 0;
}
